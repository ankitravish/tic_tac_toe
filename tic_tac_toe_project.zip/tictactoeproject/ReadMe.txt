Steps to run this code on Ganache
__________________________________


1. Download Ganache and create accounts.

2. Open Remix-Ethereum IDE in any browser and copy the solidity code ("tictactoe.sol") available in contracts folder.

3. In the environment tab, select Web3 provider.

4. In Web3 Provider Endpoint, write HTTP://127.0.0.1:7545 to connect to Ganache.

5. Deploy the code and then run.